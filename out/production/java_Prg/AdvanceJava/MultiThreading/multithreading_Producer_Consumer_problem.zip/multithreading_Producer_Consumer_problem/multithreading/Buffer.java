		public interface Buffer
		{
		   public void set( int value ); // place int value into Buffer
		   public int get(); // return int value from Buffer
		} // end interface Buffer
